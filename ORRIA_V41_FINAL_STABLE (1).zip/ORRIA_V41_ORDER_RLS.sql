-- ORRIA V41: allow guest checkout to create orders.
-- Run this once in Supabase SQL Editor. Admin read/update policies remain separate.
DROP POLICY IF EXISTS "public create orders" ON public.orders;
CREATE POLICY "public create orders"
ON public.orders
FOR INSERT TO anon
WITH CHECK (status = 'Pending' AND total >= 0);
